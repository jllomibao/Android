This app implements some starter user interface functions for a device that measures pH.
I have only implemented a few configuration variables that are saved into a SQLite database.
The values shown for pH and Temperature are constant for now. These should be replaced with 
actual measured values from a device.
A default configuration is provided to guide users of typical values.
A user manual is presented in a web view using google docs.
